import React, { useEffect } from "react";
import IwebForm from "../components/iweb-form/IwebForm";
const ZOHO = window.ZOHO;

const Home = () => {
  useEffect(() => {
    ZOHO.embeddedApp.init().then(() => {
      ZOHO.CRM.API.getAllUsers({ Type: "AllUsers" }).then(function (data) {
        console.log("USers ", data);
      });
    });
  }, []);

  return <IwebForm formSchema={formSchema} />;
};

export default Home;

const formSchema = {
  title: "Create Application",
  inputs: [
    {
      type: "autocomplete_zoho",
      name: "Account_Name",
      label: "Accounts",
      dataSource: "Accounts",
      optionLabels: ["Account_Name", "id"],
      conditions: [],
      placeholder: "Select an Account",
      grid: {
        xs: 12,
        sm: 12,
        md: 12,
        lg: 12,
        xl: 12,
      },
      size: "small",
    },

    // Button
    {
      type: "buttongroup",
      width: "40%",
      align: "center",
      color: "primary",
      grid: {
        xs: 12,
        sm: 12,
        md: 12,
        lg: 12,
        xl: 12,
      },
      buttons: [
        { buttonType: "submit", label: "Submit", color: "primary" },
        { buttonType: "popupclose", label: "Close", color: "secondary" },
      ],
    },
  ],
};
