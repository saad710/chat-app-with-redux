import mock from "./mock";
import "./chats/ChatData";
import "./notes/NotesData";

mock.onAny().passThrough();
