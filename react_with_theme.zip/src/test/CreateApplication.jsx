import Grid from "@material-ui/core/Grid";
import IwebForm from "../components/iweb-form/IwebForm";
import { useEffect } from "react";
import Container from "@material-ui/core/Container";
const ZOHO = window.ZOHO;
export default function CreateApplication() {
  useEffect(() => {
    ZOHO.embeddedApp.init();
  }, []);
  return (
    <>
      <Container maxWidth="sm">
        <Grid container spacing={1}>
          <IwebForm formSchema={formSchema} />
        </Grid>
      </Container>
    </>
  );
}
const formSchema = {
  title: "Create Application",
  inputs: [
    {
      type: "autocomplete_zoho",
      name: "Account_Name",
      label: "Accounts",
      dataSource: "Accounts",
      optionLabels: ["Account_Name", "id"],
      conditions: [],
      placeholder: "Select an Account",
      grid: {
        xs: 12,
        sm: 12,
        md: 12,
        lg: 12,
        xl: 12,
      },
      size: "small",
    },

    // Button
    {
      type: "buttongroup",
      width: "40%",
      align: "center",
      color: "primary",
      grid: {
        xs: 12,
        sm: 12,
        md: 12,
        lg: 12,
        xl: 12,
      },
      buttons: [
        { buttonType: "submit", label: "Submit", color: "primary" },
        { buttonType: "popupclose", label: "Close", color: "secondary" },
      ],
    },
  ],
};
